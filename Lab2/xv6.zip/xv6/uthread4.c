#include "types.h"
#include "stat.h"
#include "user.h"
#include "syscall.h"
#define FREE        0x0
#define RUNNING     0x1
#define RUNNABLE    0x2
#define WAIT        0x3
#define EXITED      0x4

#define STACK_SIZE  8192
#define MAX_THREAD  10
typedef struct thread thread_t, *thread_p;
typedef struct mutex mutex_t, *mutex_p;

struct thread {
  int        *sp;     /* saved stack pointer */
  int        tid;    /* thread id */
  int        ptid;   /* parent thread id */
  char stack[STACK_SIZE];
  int        state;
  void     (*func)(void);  // 실행할 함수 포인터
};

struct context {
  uint edi;
  uint esi;
  uint ebx;
  uint ebp;
  uint eip;
};

static thread_t all_thread[MAX_THREAD];
thread_p  current_thread;
thread_p  next_thread;
extern void thread_switch(void);

void thread_schedule(void) {
  thread_p t;

  next_thread = 0;
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    if (t->state == RUNNABLE) {
      next_thread = t;
      break;
    }
  }

  if (next_thread == 0) {
    printf(1, "[scheduler] no RUNNABLE threads left. exiting.\n");
    exit();
  }

  // 이전 current_thread가 EXITED면 FREE로 바꾸지 않음 (join에서 기다리므로)
  if (current_thread->state == RUNNING) {
    current_thread->state = RUNNABLE;
  }

  next_thread->state = RUNNING;
  thread_switch();
}
void 
thread_init(void) {
  uthread_init((int)thread_schedule);

  current_thread = &all_thread[0];
  current_thread->state = RUNNING;
  current_thread->tid = 0;
  current_thread->ptid = 0;
}

void thread_exit() {
  //printf(1, "thread_exit: current tid=%d, parent=%d\n", current_thread->tid, current_thread->ptid);
  current_thread->state = EXITED;

  // 부모가 나를 join하고 WAIT 중이면 깨워주기
  for (int i = 0; i < MAX_THREAD; i++) {
    if (all_thread[i].tid == current_thread->ptid && all_thread[i].state == WAIT) {
      all_thread[i].state = RUNNABLE;
      //printf(1, "[thread_exit] waking parent tid=%d from WAIT\n", all_thread[i].tid);
      next_thread = &all_thread[i];
      next_thread->state = RUNNING;
      thread_switch(); //직접 context switch 실행
      //thread_schedule();
    }
  
  }
  
  thread_schedule();
  return;
  //printf(1, "[thread_exit] fallback exit()\n");
  //exit();
}

void thread_stub(void (*func)()) {
  func();               // 스레드 진입
  thread_exit();        // 끝나면 종료
}
void thread_entry(void) {
  if (!current_thread || !current_thread->func) {
    printf(1, "[thread_entry] current_thread or func is NULL\n");
    thread_exit();
  }
  current_thread->func();  // 등록된 함수 실행
  thread_exit();           // 끝나면 정리
}
typedef unsigned int uintptr_t;
int thread_create(void (*func)(void)) {
  thread_p t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    if (t->state == FREE)
      break;
  }

  if (t >= all_thread + MAX_THREAD) {
    printf(1, "thread_create: no more threads\n");
    return -1;
  }

  t->tid = t - all_thread;
  t->ptid = current_thread->tid;
  t->state =RUNNABLE;
  t->func = func;

  // 스택 포인터 설정 (uint*로 가정)
  uint *sp = (uint*)(t->stack + STACK_SIZE);

  // 인자로 func 전달
  *(--sp) = (uint)func;               // argument
  *(--sp) = 0;                        // fake return address (never returns)
  *(--sp) = (uint)thread_entry;        // return address: thread_entry
  
  // 스택 포인터 등록
  t->sp = (int*)sp;
  printf(1, "Created thread at %p, func=%p, sp=%p\n", t, func, sp);
  return t->tid;
}

static void 
thread_join(int tid) {
  thread_p t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    if (t->tid == tid)
      break;
  }

  if (t >= all_thread + MAX_THREAD || t->state == FREE) {
    printf(1, "thread_join: no such thread %d\n", tid);
    return;
  }

  if (t->ptid != current_thread->tid) {
    printf(1, "thread_join: thread %d is not a child of current thread %d\n", tid, current_thread->tid);
    return;
  }
  current_thread->state = WAIT;
  thread_schedule();
  while (t->state != EXITED) 
  { 
    printf(1, "thread_join: waiting for tid=%d, state=%d\n", t->tid, t->state);
    current_thread->state = WAIT;
    thread_schedule();  // 자식 스레드가 종료되길 기다림
  }
  t->state = FREE;
}

void 
child_thread(void) {
  //printf(1, "child_thread addr = 0x%x\n", (int)child_thread);
  if (!current_thread) {
    printf(1, "current_thread is NULL!\n");
    exit();
  }
  printf(1, "[child_thread] 실행됨! tid=%d\n", current_thread->tid);
  for (int i = 0; i < 100; i++) {
    printf(1, "child thread 0x%x\n", (int) current_thread);
  }
  printf(1, "child thread: exit\n");
  thread_exit();
}

void 
mythread(void) {
  int tid[5];
  printf(1, "my thread running\n");

  for (int i = 0; i < 5; i++) {
    tid[i] = thread_create(child_thread);
  }
  for (int i = 0; i < 5; i++) {
    thread_join(tid[i]);
  }
  printf(1, "my thread: exit\n");
  thread_exit();
}

int 
main(int argc, char *argv[]) {
  thread_init();
  printf(1, "mythread addr = 0x%x\n", (uint)mythread);
  printf(1, "child_thread addr = 0x%x\n", (uint)child_thread);
  int tid = thread_create(mythread);
  thread_join(tid);
  thread_exit();
}


