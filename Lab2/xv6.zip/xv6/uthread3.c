#include "types.h"
#include "stat.h"
#include "user.h"

#define FREE        0x0
#define RUNNING     0x1
#define RUNNABLE    0x2
#define SUSPENDED   0x3

#define STACK_SIZE  8192
#define MAX_THREAD  10

typedef struct thread thread_t, *thread_p;

typedef struct thread {
  int tid;
  uint* sp;               // user-level stack pointer
  void* stack_base;       // malloc base for cleanup
  int state;
} thread_t;

static thread_t all_thread[MAX_THREAD];
thread_p current_thread;
thread_p next_thread;

extern void thread_switch(void);
void thread_schedule(void);
void thread_exit(void);

void thread_entry(void)
{
  printf(1, "[thread_entry] entered, sp=%p\n", current_thread->sp);
  void (*f)() = (void (*)()) *(((uint*)current_thread->sp) + 1);
  printf(1, "[thread_entry] loaded f = %p\n", f);
  f();
  thread_exit();
}

void thread_init(void)
{
  uthread_init((int)thread_schedule);
  current_thread = &all_thread[0];
  current_thread->tid = 0;
  current_thread->state = RUNNING;
  current_thread->sp = 0;
  current_thread->stack_base = 0;
}

int thread_create(void (*func)(void)) {
  thread_p t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    if (t->state == FREE)
      break;
  }

  if (t >= all_thread + MAX_THREAD) {
    printf(1, "thread_create: no more threads\n");
    return -1;
  }

  void *stack = sbrk(STACK_SIZE);
  if (stack == (void*)-1) {
  printf(1, "thread_create: sbrk failed\n");
  return -1;
  }


  uint *sp = (uint*)((char*)stack + STACK_SIZE);
  printf(1, "[stack alloc] stack base = %p\n", stack);
  printf(1, "[stack alloc] stack top = %p\n", sp);

  sp -= 7;                         // dummy context space (28B)
  *(--sp) = (uint)func;            // function pointer (argument)
  *(--sp) = (uint)thread_entry;    // return address (ret -> thread_entry)

  t->sp = sp;
  t->stack_base = stack;
  t->tid = t - all_thread;
  t->state = RUNNABLE;

  printf(1, "[thread_create] tid=%d func=%p sp=%p\n", t->tid, func, (void*)t->sp);
  return t->tid;
}

void thread_exit(void)
{
  //if (current_thread->stack_base)
  //  free(current_thread->stack_base);
  current_thread->sp = 0;
  current_thread->stack_base = 0;
  current_thread->state = FREE;
  thread_schedule();
  while (1); // never return
}

void thread_schedule(void)
{
  thread_p t;
  next_thread = 0;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    if (t->state == RUNNABLE && t != current_thread) {
      next_thread = t;
      break;
    }
  }

  if (!next_thread && current_thread->state == RUNNABLE) {
    next_thread = current_thread;
  }

  if (!next_thread) {
    printf(2, "thread_schedule: no runnable threads\n");
    exit();
  }

  if (current_thread != next_thread) {
    next_thread->state = RUNNING;
    if (current_thread->state != FREE && current_thread->state != SUSPENDED)
      current_thread->state = RUNNABLE;
    thread_switch();
  } else {
    next_thread = 0;
  }
}

static void thread_suspend(int tid)
{
  for (int i = 0; i < MAX_THREAD; i++) {
    if (all_thread[i].tid == tid && all_thread[i].state != FREE) {
      if (&all_thread[i] == current_thread) {
        all_thread[i].state = SUSPENDED;
        thread_schedule();
      } else if (all_thread[i].state == RUNNABLE) {
        all_thread[i].state = SUSPENDED;
      }
      printf(1, "suspending %d\n", tid);
      return;
    }
  }
}

static void thread_resume(int tid)
{
  for (int i = 0; i < MAX_THREAD; i++) {
    if (all_thread[i].tid == tid && all_thread[i].state == SUSPENDED) {
      all_thread[i].state = RUNNABLE;
      printf(1, "resumed %d\n", tid);
      return;
    }
  }
}

static void mythread(void)
{
  printf(1, "[mythread] entered tid = %d\n", current_thread->tid);
  for (int i = 0; i < 100; i++) {
    printf(1, "my thread %d\n", current_thread->tid);
  }
  printf(1, "my thread: exit\n");
  thread_exit();
}

int main(int argc, char *argv[])
{
  int tid1, tid2;
  thread_init();
  tid1 = thread_create(mythread);
  tid2 = thread_create(mythread);

  sleep(3);
  thread_suspend(tid1);
  sleep(3);
  thread_suspend(tid2);
  thread_resume(tid1);
  sleep(3);
  thread_resume(tid2);
  sleep(100);

  exit();
}


